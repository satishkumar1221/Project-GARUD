READ ME FILE 
-----------------------------------------HAPPY CODING :)------------------------------------------------------------------------
Individial files abd testbenches for this project  is attested in this file. 

For the alu and register combination refer to the aluandred file and the respective testbench for that is ALU_REG_COMBO_TB 

For the assn 2 the name of the file is ALU_REG_INTERCONNECT and the respective testbench for that is CLASS_ASSN2_TB

For the assn b4 the name of the file is assn4_virtulization and repective testbench is assn4_virtulization_tb 

Make sure to instantiate all the files before executing the program. Absence  of a file may lead to wrong output. 